
interface IUser {
  id: number;
  name: string;
  email: string;
}

interface ITask {
  id: number;
  title: string;
  description: string;
  assignee: IUser | null;
  status: StatusTask;
}

enum StatusTask {
  Pending,
  InProgress,
  Completed,
}

class Task implements ITask {
  constructor(
    public id: number,
    public title: string,
    public description: string,
    public assignee: IUser | null,
    public status: StatusTask
  ) {}

  updateStatus(newStatus: StatusTask): void {
    this.status = newStatus;
  }
}


class User implements IUser {
  constructor(
    public id: number,
    public name: string,
    public email: string
  ) {}

  assignTask(task: Task): void {
    task.assignee = this;
  }
}


class TaskManager {
 
  public task: Task[] = [];

 
  addTask(task: Task): void {
    this.task.push(task);
  }



yStatus(status: StatusTask): Task[] {
    const otasks: Task[] = []
    for (const t of this.task) {
        if (status === StatusTask.Pending && t.status === StatusTask.Pending) {
            otasks.push(t)
        } else if (status === StatusTask.InProgress && t.status === StatusTask.InProgress) {
            otasks.push(t)
        } else if (status === StatusTask.Completed && t.status === StatusTask.Completed) {
            otasks.push(t)
        }
    }
    return otasks;
}

   getTasksByUser(userId: number): Task[] {
    const otasks: Task[] = []
      for (const t of this.task){
        if(userId ===t.assignee?.id){
            otasks.push(t)
        }
    }
     return otasks
   }
  // Find task by ID
findTask(id: string | number): Task | undefined {
  for (const t of this.task) {
    if (typeof id === 'number' && t.id === id) {
      return t; 
    } else if (typeof id === 'string') {
      const convertedId = parseInt(id);
      if (t.id === convertedId) {
        return t; 
      }
    }
  }

  return undefined;
}
}
//  function paginate<T>(items: T[], pageSize: number,pageNumber: number): T[]
{
//    return (items[],pageSize,pageNumber)
}


   async function fetchUser(): Promise<User[]> {
  return [
    new User(1, "Ashir", "ashir@12.com"),
    new User(2, "Ali", "ali22@.com"),
    new User(3, "Ahmad", "ahmad121@.com"),
  ];
}



async function fetchTasks(): Promise<Task[]> {
  return [
    new Task(1, "Html", "Create homepage wireframe", null, StatusTask.Pending),
    new Task(2, "CSS", "Build REST endpoints", null, StatusTask.InProgress),
    new Task(3, "JS", "Add unit tests for service", null, StatusTask.Completed),
    new Task(4, "react", "Resolve critical bugs", null, StatusTask.Pending),
    new Task(5, "Deploy App", "Deploy to production", null, StatusTask.InProgress),
  ];
}

async function main() {
  const users = await fetchUser();        
  const tasks = await fetchTasks();      



  if(users.length >= 3 && tasks.length >= 5)
  {
   users[0].assignTask(tasks[0]);
}
console.log("no USER or TASK")
return

  const manager = new TaskManager();      

  for (const t of tasks) {
    manager.addTask(t);                 
  }

 console.log(" Pending Tasks:", manager.getTasksByUser(StatusTask.Pending));
  console.log(" In Progress Tasks:", manager.getTasksByUser(StatusTask.InProgress));
  console.log(" Completed Tasks:", manager.getTasksByUser(StatusTask.Completed));

  const userId = users[0].id;
console.log(` Tasks assigned to ${users[0].name}:`, manager.getTasksByUser(userId));
  
}
main();


 


