interface IUser {
  id: number;
  name: string;
  email: string;
}

interface ITask {
  id: number;
  title: string;
  description: string;
  assignee: IUser | null;
  status: StatusTask;
}

enum StatusTask {
  Pending,
  InProgress,
  Completed
}

class Task implements ITask {
  constructor(
    public id: number,
    public title: string,
    public description: string,
    public assignee: IUser | null,
    public status: StatusTask
  ) {}

  updateStatus(newStatus: StatusTask): void {
    this.status = newStatus;
  }
}


class User implements IUser {
  constructor(
    public id: number,
    public name: string,
    public email: string
  ) {}

  assignTask(task: Task): void {
    task.assignee = this;
  }
}


class TaskManager {
    static getAllTasks() {
        throw new Error("Method not implemented.");
    }
 
  public task: Task[] = [];

 
  addTask(task: Task): void {
    this.task.push(task);
  }

  getAllTasks(): Task[] {
    return this.task;
  }



getTasksByStatus(status: StatusTask): Task[] {
    const otasks: Task[] = []
    for (const t of this.task) {
        if (status === StatusTask.Pending && t.status === StatusTask.Pending) {
            otasks.push(t)
        } else if (status === StatusTask.InProgress && t.status === StatusTask.InProgress) {
            otasks.push(t)
        } else if (status === StatusTask.Completed && t.status === StatusTask.Completed) {
            otasks.push(t)
        }
    }
    return otasks;
}



   getTasksByUser(userId: number): Task[] {
    const otasks: Task[] = []
      for (const t of this.task){
        if(userId ===t.assignee?.id){
            otasks.push(t)
        }
    }
     return otasks
   }


findTask(id: string | number): Task | undefined {
  for (const t of this.task) {
    if (typeof id === 'number' && t.id === id) {
      return t; 
    } else if (typeof id === 'string') {
      const convertedId = parseInt(id);
      if (t.id === convertedId) {
        return t; 
      }
    }
  }
  return undefined;
}
}

function paginate<T>(items: T[], pageSize: number, pageNumber: number): T[] {
  const startIndex = (pageNumber - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedItems: T[] = [];

  for (let i = startIndex; i < endIndex && i < items.length; i++) {
    paginatedItems.push(items[i]);
  }

  return paginatedItems;
}

   async function fetchUser(): Promise<User[]> {
  return [
    new User(1, "Ashir", "ashir@12.com"),
    new User(2, "Ali", "ali22@.com"),
    new User(3, "Ahmad", "ahmad121@.com"),
  ];
}



async function fetchTasks(): Promise<Task[]> {
  return [
    new Task(1, "Html", "HyperTextMarkUpLanguage", null, StatusTask.Pending),
    new Task(2, "CSS", "CascadingStyleSheet", null, StatusTask.InProgress),
    new Task(3, "JS", "JavaScript", null, StatusTask.Completed),
    new Task(4, "react", "React.JS", null, StatusTask.Pending),
    new Task(5, "TS", "TypeScript", null, StatusTask.InProgress),
  ];
}




async function main() {

    //  Fetch users and tasks
  const users = await fetchUser();
  const tasks = await fetchTasks();



// Assign some tasks to users.
  if (users.length < 3 || tasks.length < 5) {
    console.log("Not enough users or tasks to proceed.");
    return;
  }

  users[0].assignTask(tasks[0]);
  users[0].assignTask(tasks[1]);
  users[1].assignTask(tasks[2]);
  users[2].assignTask(tasks[3]);
  users[2].assignTask(tasks[4]);

// add tasks
  const manager = new TaskManager();
  for (const t of tasks) {
    manager.addTask(t);
  }

//  Filter tasks by status. 


  console.log(" Pending Tasks:", manager.getTasksByStatus(StatusTask.Pending));
  console.log(" In Progress Tasks:", manager.getTasksByStatus(StatusTask.InProgress));
  console.log(" Completed Tasks:", manager.getTasksByStatus(StatusTask.Completed));

 // Filter tasks by user. 
  const userId = users[0].id;
  console.log(` Tasks assigned to ${users[0].name}:`, manager.getTasksByUser(userId));

// • Use paginate to return only 2 tasks per page and log the first page. 

const taskManager = new TaskManager();
const allTasks = taskManager.getAllTasks();
  const paginatedTasks = paginate(allTasks, 2, 1); 
  console.log(' Paginated Tasks :', paginatedTasks);

}

main();


 


